import React from 'react'

function LatestJob() {
  return (
    <div>
        <h1>Latest Job Opening</h1>

    </div>
  )
}

export default LatestJob