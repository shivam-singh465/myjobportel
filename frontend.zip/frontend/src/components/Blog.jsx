import React from 'react'
import { Navbar } from './index'

function Blog() {
  return (
    <>
      <Navbar />
      <div>Blog</div>
    </>
  )
}

export default Blog